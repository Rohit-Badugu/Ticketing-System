from flask import Flask
import requests

app = Flask(__name__)
host = ""

@app.route('/')
def index():
    response=requests.get(url, )
    return '<h1>Welcome to world of Flask!<h1>'
    
if __name__ == "__main__":
    app.run()